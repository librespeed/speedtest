<!DOCTYPE html>
<html>
<head>
<link rel="shortcut icon" href="favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no" />
<meta charset="UTF-8" />
<script type="text/javascript" src="speedtest.js"></script>
<script type="text/javascript">
function I(i){return document.getElementById(i);}

// 测试服务器列表。如果是独立安装请保持为空。详情请参阅文档
var SPEEDTEST_SERVERS=[
	/*{	// 此服务器不存在，请删除
		name:"示例服务器1", // 服务器友好名称
		server:"//test1.mydomain.com/", // 服务器URL。开头的//会自动替换为http://或https://
		dlURL:"backend/garbage.php",  // 下载测试路径(garbage.php或替代文件)
		ulURL:"backend/empty.php",  // 上传测试路径(empty.php或替代文件)
		pingURL:"backend/empty.php",  // 延迟/抖动测试路径(empty.php或替代文件)
		getIpURL:"backend/getIP.php"  // 获取IP路径(getIP.php或替代文件)
	},
	{	// 此服务器不存在，请删除
		name:"示例服务器2", // 服务器友好名称
		server:"//test2.example.com/", // 服务器URL。开头的//会自动替换为http://或https://
		dlURL:"garbage.php",  // 下载测试路径(garbage.php或替代文件)
		ulURL:"empty.php",  // 上传测试路径(empty.php或替代文件)
		pingURL:"empty.php",  // 延迟/抖动测试路径(empty.php或替代文件)
		getIpURL:"getIP.php"  // 获取IP路径(getIP.php或替代文件)
	}*/
	// 在此添加其他服务器，用逗号分隔
];

// 初始化测速工具
var s=new Speedtest(); // 创建测速对象
s.setParameter("telemetry_level","basic"); // 启用基本数据收集(用于结果分享)

// 服务器自动选择
function initServers(){
	if(SPEEDTEST_SERVERS.length==0){ // 独立安装
		// 直接显示UI界面
		I("loading").className="hidden";
		I("serverArea").style.display="none";
		I("testWrapper").className="visible";
		initUI();
	}else{ // 多服务器
		var noServersAvailable=function(){
			I("message").innerHTML="没有可用服务器";
		}
		var runServerSelect=function(){
			s.selectServer(function(server){
				if(server!=null){ // 至少有一个可用服务器
					I("loading").className="hidden"; // 隐藏加载信息
					// 为手动选择填充服务器列表
					for(var i=0;i<SPEEDTEST_SERVERS.length;i++){
						if(SPEEDTEST_SERVERS[i].pingT==-1) continue;
						var option=document.createElement("option");
						option.value=i;
						option.textContent=SPEEDTEST_SERVERS[i].name;
						if(SPEEDTEST_SERVERS[i]===server) option.selected=true;
						I("server").appendChild(option);
					}
					// 显示测试界面
					I("testWrapper").className="visible";
					initUI();
				}else{ // 没有可用服务器，无法继续测试
					noServersAvailable();
				}
			});
		}
		if(typeof SPEEDTEST_SERVERS === "string"){
			// 需要从指定URL获取服务器列表
			s.loadServerList(SPEEDTEST_SERVERS,function(servers){
				if(servers==null){ // 加载服务器列表失败
					noServersAvailable();
				}else{ // 服务器列表加载成功
					SPEEDTEST_SERVERS=servers;
					runServerSelect();
				}
			});
		}else{
			// 硬编码的服务器列表
			s.addTestPoints(SPEEDTEST_SERVERS);
			runServerSelect();
		}
	}
}

var meterBk=/Trident.*rv:(\d+\.\d+)/i.test(navigator.userAgent)?"#EAEAEA":"#80808040";
var dlColor="#6060AA",
	ulColor="#616161";
var progColor=meterBk;

// 仪表盘代码
function drawMeter(c,amount,bk,fg,progress,prog){
	var ctx=c.getContext("2d");
	var dp=window.devicePixelRatio||1;
	var cw=c.clientWidth*dp, ch=c.clientHeight*dp;
	var sizScale=ch*0.0055;
	if(c.width==cw&&c.height==ch){
		ctx.clearRect(0,0,cw,ch);
	}else{
		c.width=cw;
		c.height=ch;
	}
	ctx.beginPath();
	ctx.strokeStyle=bk;
	ctx.lineWidth=12*sizScale;
	ctx.arc(c.width/2,c.height-58*sizScale,c.height/1.8-ctx.lineWidth,-Math.PI*1.1,Math.PI*0.1);
	ctx.stroke();
	ctx.beginPath();
	ctx.strokeStyle=fg;
	ctx.lineWidth=12*sizScale;
	ctx.arc(c.width/2,c.height-58*sizScale,c.height/1.8-ctx.lineWidth,-Math.PI*1.1,amount*Math.PI*1.2-Math.PI*1.1);
	ctx.stroke();
	if(typeof progress !== "undefined"){
		ctx.fillStyle=prog;
		ctx.fillRect(c.width*0.3,c.height-16*sizScale,c.width*0.4*progress,4*sizScale);
	}
}
function mbpsToAmount(s){
	return 1-(1/(Math.pow(1.3,Math.sqrt(s))));
}
function format(d){
    d=Number(d);
    if(d<10) return d.toFixed(2);
    if(d<100) return d.toFixed(1);
    return d.toFixed(0);
}

// UI界面代码
var uiData=null;
function startStop(){
    if(s.getState()==3){
		// 测速正在进行，中止
		s.abort();
		data=null;
		I("startStopBtn").className="";
		I("server").disabled=false;
		I("ip").textContent="";
		initUI();
	}else{
		// 测试未运行，开始测试
		I("startStopBtn").className="running";
		//I("shareArea").style.display="none";
		I("shareArea").style.display="";
		I("server").disabled=true;
		s.onupdate=function(data){
            uiData=data;
		};
		s.onend=function(aborted){
            I("startStopBtn").className="";
            I("server").disabled=false;
            updateUI(true);
            if(!aborted){
                // 如果存在testId，显示分享面板，否则不执行任何操作
                try{
                    var testId=uiData.testId;
                    if(testId!=null){
                        var shareURL=window.location.href.substring(0,window.location.href.lastIndexOf("/"))+"/results/?id="+testId;
                        I("resultsImg").src=shareURL;
                        I("resultsURL").value=shareURL;
                        I("testId").innerHTML=testId;
                        I("shareArea").style.display="";
                    }
                }catch(e){}
            }
		};
		s.start();
	}
}
// 此函数读取测试返回的数据并更新UI界面
function updateUI(forced){
	if(!forced&&s.getState()!=3) return;
	if(uiData==null) return;
	var status=uiData.testState;
	I("ip").textContent=uiData.clientIp;
	I("dlText").textContent=(status==1&&uiData.dlStatus==0)?"...":format(uiData.dlStatus);
	drawMeter(I("dlMeter"),mbpsToAmount(Number(uiData.dlStatus*(status==1?oscillate():1))),meterBk,dlColor,Number(uiData.dlProgress),progColor);
	I("ulText").textContent=(status==3&&uiData.ulStatus==0)?"...":format(uiData.ulStatus);
	drawMeter(I("ulMeter"),mbpsToAmount(Number(uiData.ulStatus*(status==3?oscillate():1))),meterBk,ulColor,Number(uiData.ulProgress),progColor);
	I("pingText").textContent=format(uiData.pingStatus);
	I("jitText").textContent=format(uiData.jitterStatus);
}
function oscillate(){
	return 1+0.02*Math.sin(Date.now()/100);
}
// 每帧更新UI界面
window.requestAnimationFrame=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.msRequestAnimationFrame||(function(callback,element){setTimeout(callback,1000/60);});
function frame(){
	requestAnimationFrame(frame);
	updateUI();
}
frame(); // 启动帧循环
// 初始化UI界面的函数
function initUI(){
	drawMeter(I("dlMeter"),0,meterBk,dlColor,0);
	drawMeter(I("ulMeter"),0,meterBk,ulColor,0);
	I("dlText").textContent="";
	I("ulText").textContent="";
	I("pingText").textContent="";
	I("jitText").textContent="";
	I("ip").textContent="";
}
</script>
<style type="text/css">
    :root {
  --text-color: #202020;
  --border-color: #ddd;
  --hover-bg: rgba(0,0,0,0.05);
  --header-bg: rgba(255,255,255,0.1);
}
	html,body{
		border:none; padding:0; margin:0;
		background:#FFFFFF;
		color:#202020;
	}
	body{
		text-align:center;
		font-family:"Microsoft YaHei","Roboto",sans-serif;
	}
	h1{
		color:#404040;
	}
	#loading{
		background-color:#FFFFFF;
		color:#404040;
		text-align:center;
	}
	span.loadCircle{
		display:inline-block;
		width:2em;
		height:2em;
		vertical-align:middle;
		background:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAAP1BMVEUAAAB2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZyFzwnAAAAFHRSTlMAEvRFvX406baecwbf0casimhSHyiwmqgAAADpSURBVHja7dbJbQMxAENRahnN5lkc//5rDRAkDeRgHszXgACJoKiIiIiIiIiIiIiIiIiIiIj4HHspsrpAVhdVVguzrA4OWc10WcEqpwKbnBo0OU1Q5NSpsoJFTgOecrrdEag85DRgktNqfoEdTjnd7hrEHMEJvmRUYJbTYk5Agy6nau6Abp5Cm7mDBtRdPi9gyKdU7w4p1fsLvyqs8hl4z9/w3n/Hmr9WoQ65lAU4d7lMYOz//QboRR5jBZibLMZdAR6O/Vfa1PlxNr3XdS3HzK/HVPRu/KnLs8iAOh993VpRRERERMT/fAN60wwWaVyWwAAAAABJRU5ErkJggg==');
		background-size:2em 2em;
		margin-right:0.5em;
		animation: spin 0.6s linear infinite;
	}
	@keyframes spin{
		0%{transform:rotate(0deg);}
		100%{transform:rotate(359deg);}
	}
	#startStopBtn{
		display:inline-block;
		margin:0 auto;
		color:#6060AA;
		background-color:rgba(0,0,0,0);
		border:0.15em solid #6060FF;
		border-radius:0.3em;
		transition:all 0.3s;
		box-sizing:border-box;
		width:8em; height:3em;
		line-height:2.7em;
		cursor:pointer;
		box-shadow: 0 0 0 rgba(0,0,0,0.1), inset 0 0 0 rgba(0,0,0,0.1);
	}
	#startStopBtn:hover{
		box-shadow: 0 0 2em rgba(0,0,0,0.1), inset 0 0 1em rgba(0,0,0,0.1);
	}
	#startStopBtn.running{
		background-color:#FF3030;
		border-color:#FF6060;
		color:#FFFFFF;
		transform: translateY(-5px);
	}
	#startStopBtn:before{
		content:"开始测试";
	}
	#startStopBtn.running:before{
		content:"终止测试";
	}
	#serverArea{
		margin-top:1em;
	}
	#server{
		font-size:1em;
		padding:0.2em;
	}
	#test{
		margin-top:2em;
		margin-bottom:12em;
	}
	div.testArea{
		display:inline-block;
		width:16em;
		height:12.5em;
		position:relative;
		box-sizing:border-box;
		transition: transform 0.3s; /* 添加悬停动效 */
	}
	.testArea:hover {
        transform: translateY(-5px);
    }
	div.testArea2{
		display:inline-block;
		width:14em;
		height:7em;
		position:relative;
		box-sizing:border-box;
		text-align:center;
		transition: transform 0.3s; /* 添加悬停动效 */
	}
	div.testArea div.testName{
		position:absolute;
		top:0.1em; left:0;
		width:100%;
		font-size:1.4em;
		z-index:9;
	}
	div.testArea2 div.testName{
        display:block;
        text-align:center;
        font-size:1.4em;
	}
	div.testArea div.meterText{
		position:absolute;
		bottom:1.55em; left:0;
		width:100%;
		font-size:2.5em;
		z-index:9;
		transition: transform 0.3s; /* 添加悬停动效 */
	}
	div.testArea div.meterText:hover{
		transform: translateY(-5px);
	}
	div.meterText{
		transition: transform 0.3s; /* 添加悬停动效 */
	}
	div.meterText:hover{
		transform: translateY(-5px);
	}
	div.testArea2 div.meterText{
        display:inline-block;
        font-size:2.5em;
	}
	div.meterText:empty:before{
		content:"0.00";
	}
	div.testArea div.unit{
		position:absolute;
		bottom:2em; left:0;
		width:100%;
		z-index:9;
	}
	div.testArea2 div.unit{
		display:inline-block;
	}
	div.testArea canvas{
		position:absolute;
		top:0; left:0; width:100%; height:100%;
		z-index:1;
	}
	div.testGroup{
		display:block;
        margin: 0 auto;
	}
	#shareArea{
		width:95%;
		max-width:40em;
		margin:0 auto;
		margin-top:2em;
	}
	#shareArea > *{
		display:block;
		width:100%;
		height:auto;
		margin: 0.25em 0;
	}
	#privacyPolicy{
        position:fixed;
        top:2em;
        bottom:2em;
        left:2em;
        right:2em;
        overflow-y:auto;
        width:auto;
        height:auto;
        box-shadow:0 0 3em 1em #000000;
        z-index:999999;
        text-align:left;
        background-color:#FFFFFF;
        padding:1em;
	}
	a.privacy{
        text-align:center;
        font-size:0.8em;
        color:#808080;
        padding: 0 3em;
	}
    div.closePrivacyPolicy {
        width: 100%;
        text-align: center;
    }
    div.closePrivacyPolicy a.privacy {
        padding: 1em 3em;
    }
	@media all and (max-width:40em){
		body{
			font-size:0.8em;
		}
	}
	div.visible{
		animation: fadeIn 0.4s;
		display:block;
	}
	div.hidden{
		animation: fadeOut 0.4s;
		display:none;
	}
	@keyframes fadeIn{
		0%{
			opacity:0;
		}
		100%{
			opacity:1;
		}
	}
	@keyframes fadeOut{
		0%{
			display:block;
			opacity:1;
		}
		100%{
			display:block;
			opacity:0;
		}
	}
	@media all and (prefers-color-scheme: dark){
	    :root {
    --text-color: #F4F4F4;
    --border-color: #444;
    --hover-bg: rgba(255,255,255,0.05);
    --header-bg: rgba(0,0,0,0.1);
  }
		html,body,#loading{
			background:#202020;
			color:#F4F4F4;
		}
		h1{
			color:#E0E0E0;
		}
		a{
			color:#9090FF;
		}
		#privacyPolicy{
			background:#000000;
		}
		#resultsImg{
			filter: invert(1);
		}
	}
	
	/* 在原有CSS中添加表格样式 */
.history-table {
  width: 100%;
  border-collapse: collapse;
  margin: 1em 0;
  background: transparent;
  color: var(--text-color);
}

.history-table th,
.history-table td {
  padding: 12px 15px;
  text-align: left;
  border-bottom: 1px solid var(--border-color);
}

.history-table th {
  background-color: var(--header-bg);
  font-weight: 600;
  backdrop-filter: blur(3px);
}

.history-table tr:hover {
  background-color: var(--hover-bg);
}

@media screen and (max-width: 600px) {
    .history-table {
        font-size: 0.9em;
    }
    .history-table td, 
    .history-table th {
        padding: 8px;
    }
    .testGroup {
        flex-direction: column; /* 小屏纵向排列 */
        gap: 1em;
    }
    .testArea {
        min-width: auto;   /* 重置最小宽度 */
        max-width: 100%;    /* 全宽显示 */
    }
}
</style>
<title>爱堡云 - 香港测速节点</title>
</head>
<body onload="initServers()">
<h1>爱堡云 - 香港测速节点</h1>
<h3>（本测速节点源服务器为CMI线路，尚在优化，暂时对移动用户比较友好）
<div id="loading" class="visible">
	<p id="message"><span class="loadCircle"></span>正在选择服务器...</p>
</div>
<div id="testWrapper" class="hidden">
	<div id="startStopBtn" onclick="startStop()"></div><br/>
	<a class="privacy" href="#" onclick="I('privacyPolicy').style.display=''">隐私政策</a>
	<div id="serverArea">
		服务器: <select id="server" onchange="s.setSelectedServer(SPEEDTEST_SERVERS[this.value])"></select>
	</div>
	<div id="test">
		<div class="testGroup">
            <div class="testArea2">
				<div class="testName">网络延迟</div>
				<div id="pingText" class="meterText" style="color:#AA6060"></div>
				<div class="unit">毫秒</div>
			</div>
			<div class="testArea2">
				<div class="testName">网络抖动</div>
				<div id="jitText" class="meterText" style="color:#AA6060"></div>
				<div class="unit">毫秒</div>
			</div>
		</div>
		<div class="testGroup">
			<div class="testArea">
				<div class="testName">下载速度</div>
				<canvas id="dlMeter" class="meter"></canvas>
				<div id="dlText" class="meterText"></div>
				<div class="unit">Mbps</div>
			</div>
			<div class="testArea">
				<div class="testName">上传速度</div>
				<canvas id="ulMeter" class="meter"></canvas>
				<div id="ulText" class="meterText"></div>
				<div class="unit">Mbps</div>
			</div>
		</div>
		<div id="ipArea">
			<span id="ip"></span>
		</div>
		<div id="shareArea">
    <h3>历史测速记录</h3>
    <?php
    // 数据库配置
    //$servername = "localhost";
    //$username = "数据库用户名";
    //$password = "数据库密码";
    //$dbname = "数据库名称";
    include('./results/telemetry_settings.php');

    // 创建连接
    $conn = new mysqli($MySql_hostname, $MySql_username, $MySql_password, $MySql_databasename);

    // 检查连接
    if ($conn->connect_error) {
        die("数据库连接失败: " . $conn->connect_error);
    }

    // 查询数据（按时间倒序排列）
    $sql = "SELECT ID, ip, dl, ul, timestamp FROM speedtest_users ORDER BY timestamp DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<table class="history-table">
                <tr>
                    <th>ID</th>
                    <th>IP地址</th>
                    <th>下载速度 (Mbps)</th>
                    <th>上传速度 (Mbps)</th>
                    <th>测试时间</th>
                </tr>';
        
        // 输出每行数据
        while($row = $result->fetch_assoc()) {
            // 处理IP地址脱敏
            $id = $row["ID"];
            $ip = $row["ip"];
            $ipParts = explode(".", $ip);
            if(count($ipParts) == 4) {
                $ipParts[1] = str_repeat("*", strlen($ipParts[1]));
                $ipParts[2] = str_repeat("*", strlen($ipParts[2]));
                $maskedIp = implode(".", $ipParts);
            } else {
                $maskedIp = "***.***.***";
            }
            
            echo '<tr>
                    <td>'.$id.'</td>
                    <td>'.$maskedIp.'</td>
                    <td>'.number_format($row["dl"], 2).'</td>
                    <td>'.number_format($row["ul"], 2).'</td>
                    <td>'.date("Y-m-d H:i:s", strtotime($row["timestamp"])).'</td>
                  </tr>';
        }
        echo '</table>';
    } else {
        echo "<p>暂无历史记录</p>";
    }
    $conn->close();
    ?>
</div>
	</div>
	<a href="https://github.com/librespeed/speedtest">源代码</a>
</div>
<div id="privacyPolicy" style="display:none">
    <h2>隐私政策</h2>
    <p>本HTML5测速服务器配置了数据收集功能。</p>
    <h4>我们收集的数据</h4>
    <p>
        在测试结束时，以下数据将被收集并存储：
        <ul>
            <li>测试ID</li>
            <li>测试时间</li>
            <li>测试结果(下载和上传速度、延迟和抖动)</li>
            <li>IP地址</li>
            <li>ISP信息</li>
            <li>大致位置(根据IP地址推断，非GPS定位)</li>
            <li>用户代理和浏览器语言设置</li>
            <li>测试日志(不包含个人信息)</li>
        </ul>
    </p>
    <h4>数据用途</h4>
    <p>
        通过本服务收集的数据用于：
        <ul>
            <li>允许分享测试结果(论坛可分享图片等)</li>
            <li>改进服务质量(例如检测我们这边的问题)</li>
        </ul>
        不会向第三方披露任何个人信息。
    </p>
    <h4>您的同意</h4>
    <p>
        开始测试即表示您同意本隐私政策的条款。
    </p>
    <h4>数据删除</h4>
    <p>
        如需删除您的信息，您需要提供测试ID或您的IP地址。这是识别您数据的唯一方式，没有这些信息我们将无法满足您的请求。<br/><br/>
        所有删除请求请联系此邮箱地址：<a href="mailto:PUT@YOUR_EMAIL.HERE">1701983190@qq.com</a>。
    </p>
    <br/><br/>
    <div class="closePrivacyPolicy">
        <a class="privacy" href="#" onclick="I('privacyPolicy').style.display='none'">关闭</a>
    </div>
    <br/>
</div>
</body>
</html>